import pygame
import os
import sys

class AudioManager:
    def __init__(self):
        self.sounds = {}
        # v0.7.0: Ruta relativa directa para máxima compatibilidad en Web
        self.sounds_dir = "sounds"
        self.master_volume = 0.5  # Volumen maestro (0.0 a 1.0)
        self.sound_base_volumes = {} # Guardamos los volúmenes base originales
        
        # v0.7.0: Desactivar carga de audio en Web para evitar errores de formato .wav
        self.is_web = sys.platform == "emscripten"
        
        if not self.is_web:
            self.load_all_sounds()
            pygame.mixer.set_num_channels(32)

    def load_all_sounds(self):
        sound_configs = {
            "hit": ("hit.wav", 0.7),
            "pop": ("pop.wav", 0.7),
            "item_get": ("item_get.wav", 0.4),
            "error": ("error.wav", 0.4),
            "fire": ("fire.wav", 0.4),
            "uuui": ("uuui.wav", 0.6),
            "bell": ("campana.wav", 0.5),
            "divine": ("divino.wav", 0.6),
            "life": ("vida.wav", 0.6),
            "match_point": ("match_point_bell.wav", 0.6),
            "golden_goal": ("golden_goal.wav", 0.7),
            "explosion": ("explosion.wav", 0.8),
            "hadouken": ("hadouken.wav", 0.6),
            "x2": ("x2.wav", 0.7),
            "ghost": ("fantasma.wav", 0.8),
            "nom": ("nom.wav", 0.8),
            "squeak": ("squeak.wav", 0.4),
            "pium": ("pium.wav", 0.6),
            "reveal": ("reveal.wav", 0.6),
            "victory_arcade": ("victory_arcade.wav", 0.8),
            "sleep_shoot": ("sleep_shoot.wav", 0.7),
            "sleep": ("sleep.wav", 0.7)
        }

        for name, (filename, vol) in sound_configs.items():
            # v0.7.0 Smart Loader: Priorizar .ogg para Web, fallback a .wav
            base_name = os.path.splitext(filename)[0]
            ogg_path = os.path.join(self.sounds_dir, f"{base_name}.ogg")
            wav_path = os.path.join(self.sounds_dir, f"{base_name}.wav")
            
            # Elegir la mejor ruta disponible
            path = ogg_path if os.path.exists(ogg_path) else wav_path
            
            if os.path.exists(path):
                try:
                    sound = pygame.mixer.Sound(path)
                    self.sounds[name] = sound
                    self.sound_base_volumes[name] = vol
                    sound.set_volume(vol * self.master_volume)
                except Exception as e:
                    print(f"Error cargando {name} desde {path}: {e}")
            else:
                print(f"Advertencia: No se encontró el sonido {base_name} (.ogg o .wav)")

    def play(self, name, loops=0, fadeout=0):
        if self.is_web: return # v0.7.0 Silencio en Web
        if name in self.sounds:
            self.sounds[name].set_volume(self.sound_base_volumes[name] * self.master_volume)
            if fadeout > 0:
                self.sounds[name].fadeout(fadeout)
            else:
                self.sounds[name].play(loops)
        else:
            # Silenciamos el log en producción para no saturar la consola del navegador
            pass

    def stop(self, name):
        if name in self.sounds:
            self.sounds[name].stop()

    def fadeout(self, name, time):
        if name in self.sounds:
            self.sounds[name].fadeout(time)

    def play_music(self, filename, volume=0.5, fade_ms=1500):
        if self.is_web: return # v0.7.0 Silencio en Web
        # v0.7.0 Smart Loader para Música
        base_name = os.path.splitext(filename)[0]
        ogg_path = os.path.join(self.sounds_dir, f"{base_name}.ogg")
        wav_path = os.path.join(self.sounds_dir, f"{base_name}.wav")
        
        path = ogg_path if os.path.exists(ogg_path) else wav_path
        
        if os.path.exists(path):
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.set_volume(volume * self.master_volume)
                pygame.mixer.music.play(-1, fade_ms=fade_ms) # Loop eterno con FadeIn
            except Exception as e:
                print(f"Error cargando música {path}: {e}")

    def stop_music(self, fadeout_ms=1500):
        pygame.mixer.music.fadeout(fadeout_ms)

    def set_music_volume(self, volume):
        pygame.mixer.music.set_volume(volume * self.master_volume)
